// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Entity, World

public abstract class EntityWeatherEffect extends Entity
{

    public EntityWeatherEffect(World world)
    {
        super(world);
    }
}
