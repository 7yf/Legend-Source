// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


public class ModelBed
{

    public ModelBed()
    {
    }

    public static final int field_22280_a[] = {
        3, 4, 2, 5
    };
    public static final int field_22279_b[] = {
        2, 3, 0, 1
    };
    public static final int bedDirection[][] = {
        {
            1, 0, 3, 2, 5, 4
        }, {
            1, 0, 5, 4, 2, 3
        }, {
            1, 0, 2, 3, 4, 5
        }, {
            1, 0, 4, 5, 3, 2
        }
    };

}
