// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            ModelQuadruped

public class ModelPig extends ModelQuadruped
{

    public ModelPig()
    {
        super(6, 0.0F);
    }

    public ModelPig(float f)
    {
        super(6, f);
    }
}
