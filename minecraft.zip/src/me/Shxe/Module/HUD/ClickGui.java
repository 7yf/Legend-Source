package net.minecraft.src.me.Shxe.Module.HUD;

import org.lwjgl.input.Keyboard;

import net.minecraft.src.me.Shxe.Module.module;


public class ClickGui extends module {

	public ClickGui(){
		super("ClickGui", Keyboard.KEY_RSHIFT, Category.RENDER);
	}
	
}
