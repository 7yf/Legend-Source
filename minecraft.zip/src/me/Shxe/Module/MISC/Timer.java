package net.minecraft.src.me.Shxe.Module.MISC;

import org.lwjgl.input.Keyboard;

import net.minecraft.src.me.Shxe.Module.module;

public class Timer extends module {

	public Timer(){
		super("Timer", Keyboard.KEY_F6, Category.MISC);
	}
	
}
