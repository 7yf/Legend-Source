package net.minecraft.src.me.Shxe.Module.RENDER;

import org.lwjgl.input.Keyboard;

import net.minecraft.src.me.Shxe.Module.module;
import net.minecraft.src.me.Shxe.Module.module.Category;

public class NCI extends module{

	public NCI(){
		super("NoChat", Keyboard.KEY_LBRACKET, Category.MOVEMENT);
	}
	
}
