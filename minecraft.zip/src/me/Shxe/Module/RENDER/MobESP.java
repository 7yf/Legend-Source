package net.minecraft.src.me.Shxe.Module.RENDER;

import org.lwjgl.input.Keyboard;

import net.minecraft.src.me.Shxe.Module.module;
import net.minecraft.src.me.Shxe.Module.module.Category;

public class MobESP extends module {
	
	public MobESP(){
		super("ESP[M]", Keyboard.KEY_NONE, Category.RENDER);
	}
	

}
