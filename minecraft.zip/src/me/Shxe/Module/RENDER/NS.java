package net.minecraft.src.me.Shxe.Module.RENDER;

import org.lwjgl.input.Keyboard;

import net.minecraft.src.me.Shxe.Module.module;
import net.minecraft.src.me.Shxe.Module.module.Category;

public class NS extends module{
	
	public NS(){
		super("NoSwing", Keyboard.KEY_N, Category.RENDER);
	}
	
}
