package net.minecraft.src.me.Shxe.Module.RENDER;

import org.lwjgl.input.Keyboard;

import net.minecraft.src.me.Shxe.Module.module;

public class FB extends module {

	public FB(){
		super("FullBright", Keyboard.KEY_C, Category.RENDER);
	}
	
}
