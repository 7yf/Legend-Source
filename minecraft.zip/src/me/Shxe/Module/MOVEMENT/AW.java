package net.minecraft.src.me.Shxe.Module.MOVEMENT;

import org.lwjgl.input.Keyboard;

import net.minecraft.src.me.Shxe.Module.module;
import net.minecraft.src.me.Shxe.Module.module.Category;

public class AW extends module{

	public AW(){
		super("AutoWalk", Keyboard.KEY_F7, Category.MOVEMENT);
	}
	
}
