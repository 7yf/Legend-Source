package net.minecraft.src.me.Shxe.Module.COMBAT;

import org.lwjgl.input.Keyboard;

import net.minecraft.src.me.Shxe.Module.module;

public class AutoHit extends module {

	public AutoHit(){
		super("AutoHit", Keyboard.KEY_R, Category.COMBAT);
	}
	
}
