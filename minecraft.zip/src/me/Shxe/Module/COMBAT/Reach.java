package net.minecraft.src.me.Shxe.Module.COMBAT;

import org.lwjgl.input.Keyboard;

import net.minecraft.src.me.Shxe.Module.module;
import net.minecraft.src.me.Shxe.Module.module.Category;

public class Reach extends module{
	
	public Reach(){
		super("Reach", Keyboard.KEY_H, Category.RENDER);
	}

}
