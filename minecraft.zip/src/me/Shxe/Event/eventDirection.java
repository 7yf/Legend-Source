package net.minecraft.src.me.Shxe.Event;

public enum eventDirection {

	INCOMING,
	OUTGOING,
	
}
