package net.minecraft.src.me.Shxe.Event.Listeners;

import net.minecraft.src.me.Shxe.Event.event;

public class eventUpdate extends event<eventUpdate>{
	
	
	
}
