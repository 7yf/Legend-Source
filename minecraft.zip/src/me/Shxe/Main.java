package net.minecraft.src.me.Shxe;

import org.lwjgl.opengl.Display;

/*
 * Comment by Shxe : These are just references mostly joke ones from when it was private ( Some before it was called Legend )
 */

public class Main {
	
	public static final String NAME = "Legend";
	public static final String NAME_1 = "Skeet";
	public static final String NAME_2 = "Gamesense";
	public static final String DEBUG = "DEBUG";
	public static final String VERSION = "1.0.0";
	public static final String DOMAIN_1 = "Skeet.cc";
	public static final String DOMAIN_2 = "Gamesense.pub";
	public static final String MC_VERSION = "Beta 1.7.3";
	
	public void onStartup() {
		Display.setTitle(NAME + VERSION);
		
		// this doesn't work :(
	}
}
